---
name: archive-articles
description: This skill should be used when the user says "整理学习内容", "归档文章", or provides WeChat public account (公众号) article links for archiving. It handles fetching article content from WeChat links, downloading images, creating structured directories, saving article content, generating review files, and optionally updating the interest_stock.md watchlist with 标的 entries.
---

# 文章采集归档 (Archive Articles)

## Overview

Processes user-provided WeChat public account (微信公众号) article links by:
1. Fetching full article text and images
2. Creating structured project directories
3. Saving formatted article content
4. Generating review files with user's notes
5. Optionally updating interest_stock.md with 标的 entries

## Trigger

用户说"整理学习内容"、"归档"、"归档文章"、或提供公众号链接时启动。

## Input

- 学习笔记文件：`{project_root}/3_学习输出/学习.md` 或 `学习.txt`
- 笔记格式：每篇文章以微信链接行开头，后跟感悟/摘录，可选 `【标的】` 行：
  ```
  https://mp.weixin.qq.com/s/xxxxx
  感悟/摘录内容（可能多行）
  【标的】题材名：标的1、标的2、标的3
  ```
- 只有 `【标的】` 开头的行才触发 interest_stock.md 更新

## Workflow

### Step 1: Parse Input

1. 读取 `3_学习输出/学习.md`（或 `学习.txt`）
2. 解析所有文章条目：
   - 链接行：以 `https://mp.weixin.qq.com/s/` 开头
   - 感悟/摘录行：链接之后、下一个链接或文件末尾之间的非空行
   - 标的行：以 `【标的】` 开头，格式 `题材名：标的1、标的2`
   - 记录学习时间区间：最早链接日期 ~ 最晚链接日期

### Step 1.5: Deduplicate Links

在对每个链接执行采集前，先做两层去重：

**1. 链接级去重（学习笔记内）**
- 对 学习.txt 中的所有链接去重，**保留首次出现的条目**（含其后的感悟/摘录/标的行）
- 后续重复链接及其附带的笔记内容直接丢弃
- 打印提示：`⏭️ 跳过重复链接: {链接}`

**2. 目录级去重（已学习文章内）**
- 对每个链接，先用 web_fetch 获取标题
- 然后检查 `2_已学习文章/` 下是否存在同名目录（模糊匹配公众号+日期+标题关键词）
- 如果已存在：
  - **跳过采集步骤**（不重新 fetch、不下载图片、不覆盖已有文章内容.md）
  - 但 **仍保留该文章的感悟/摘录内容**，写入待审阅文件
  - 打印提示：`⏭️ 文章已归档，跳过采集: {公众号}_{日期}_{标题}`
  - 不更新 context.md 和 state.md（非新增文章）

### Step 2: Fetch Each Article

对每个**未去重、未归档**的链接按顺序执行：

1. **web_fetch** — 快速获取文章标题、作者、发布时间、正文内容（验证链接有效性）
2. **playwright-cli** — 用浏览器打开文章页面，提取图片 URL：
   ```bash
   npx playwright-cli open <url>
   npx playwright-cli eval "Array.from(document.querySelectorAll('img')).map(i => i.src || i.getAttribute('data-src')).filter(Boolean)"
   ```
3. **下载图片** — 用 `curl` 下载非 data: URI 的真实图片，扩展名从 URL 中 `wx_fmt` 参数确定
4. **关闭浏览器**：`npx playwright-cli close`
5. 文章目录命名格式：`{公众号}_{日期}_{标题}/`，自动处理特殊字符

### Step 3: Create Directory Structure

在 `2_已学习文章/` 下为每篇文章创建：

```
{公众号}_{日期}_{标题}/
├── 文章内容.md       # 格式化后的文章全文
├── images/           # 下载的配图
└── data/             # （可选）结构化数据
```

### Step 4: Write 文章内容.md

格式规范：

```markdown
# {文章标题}

**公众号**：{作者}
**发布时间**：{日期} {时间}
**文章链接**：{链接}

---

## 正文内容

{正文内容，保留原文段落格式}

![图片描述](images/image1.ext)

---

**免责声明**：{免责声明内容}
```

作者特定处理：
| 作者 | 标题规律 | 免责声明 |
|------|---------|---------|
| 爱在冰川 | ZMYK="周末愉快"; 数据类用 `{日期} 数据` | **特别提示**：文中股票仅为鄙人的思考过程... |
| 股痴流沙河 | 单/双字标题（逻辑、变局等） | **免责声明**：本文内容仅为作者个人观点... |
| 橙子不糊涂 | 长句标题，常用感叹号 | 同股痴流沙河 |
| 安静拆主线/争气2026 | 偏短句/理念型 | 同股痴流沙河 + 资格证号 |
| 小睿睿投资学/小睿睿8 | 日期+主题（6.1 传统缅A等） | **免责声明**：本文仅是我个人的观点... |

### Step 5: Generate Review File

创建 `3_学习输出/学习_{当天日期}_待审阅.md`：

```markdown
学习时间区间：2026-06-01 ~ 2026-06-17

---
【文章1标题】
链接：https://mp.weixin.qq.com/s/xxxxx

感悟/摘录内容...

---
【文章2标题】
...
```

### Step 6: Update interest_stock.md

仅处理 `【标的】` 开头的行：
1. 智能匹配题材：优先归入已有题材名（如"铜箔"→`# PCB`，"液冷"→`# 液冷`）
2. 已有题材：在下面追加新标的（去重）
3. 无对应题材：新增一级标题
4. 标的名称需通过 web_search 验证正确性
5. 写入格式：`标的名称（异动原因）`，中文括号
6. 格式规范：每个 `# 题材` 上方留空行，标题后紧跟股票列表

### Step 7: Update context.md（仅新增文章）

仅对**本次新采集的文章**更新 `context.md`：
- 在对应作者下追加新文章（日期、标题、图片数、状态）
- 更新作者文章总数
- 更新最后更新日期
- 已归档跳过的文章不更新（已有记录）

### Step 8: Update state.md（仅新增文章）

仅对**本次新采集的文章**更新 `state.md`：
- 更新总文章数
- 记录最近完成的操作
- 更新最后更新日期

## 约束

- 必须使用 playwright-cli 获取图片（web_fetch 无法获取微信图片）
- 图片必须下载到本地 images/ 目录
- 封面图不获取
- 不清空用户原始笔记文件
- 文章内容.md 只保留文章内容和图片（给人看），技术细节记入 process_insight.md

## Rule: Single source of truth

标的文件统一写入 `2_projects/中长线逻辑识别/interest_stock.md`，所有项目（公众号文章梳理、涨停板复盘）共用此文件。
