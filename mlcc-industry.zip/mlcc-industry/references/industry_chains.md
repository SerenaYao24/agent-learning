# 预设产业链及跟踪标的

本文件存储 Skill 内置的预设产业链数据。如需添加/修改/删除产业链，直接编辑此文件即可。

---

## MLCC/电容 产业链

**名称关键词**：MLCC、电容、被动元件、铝电解电容、陶瓷电容

**跟踪标的**：

| 序号 | 公司名称 | 所属地区 | 主营业务 | 搜索关键词 |
|------|---------|---------|---------|-----------|
| 1 | 村田制作所 (Murata) | 日本 | MLCC全球龙头，AI服务器MLCC份额70%+ | 村田, Murata, 6981.TYO |
| 2 | 三星电机 (Samsung Electro-Mechanics) | 韩国 | MLCC全球第二，硅电容业务 | 三星电机, Samsung Electro-Mechanics |
| 3 | 国巨 (Yageo) | 中国台湾 | MLCC、芯片电阻，全球第三大被动元件厂 | 国巨, Yageo |
| 4 | 尼吉康 (Nichicon) | 日本 | 铝电解电容龙头 | 尼吉康, Nichicon |
| 5 | 风华高科 | 中国 | MLCC、电阻，国内被动元件龙头 | 风华高科 |
| 6 | 艾华集团 | 中国 | 铝电解电容，全球第六 | 艾华集团 |
| 7 | 江海股份 | 中国 | 铝电解电容、超级电容 | 江海股份 |

---

## 产业链模板（可参考添加）

如需添加新产业链，按以下格式填写：

```yaml
- name: [产业链名称]
  keywords: [触发关键词列表]
  stocks:
    - name: [公司名称]
      region: [所属地区/国家]
      business: [主营业务描述]
      search_keywords: [搜索关键词]
```

示例：

```yaml
- name: 锂电池 产业链
  keywords: ["锂电池", "锂电", "电池"]
  stocks:
    - name: 宁德时代
      region: 中国
      business: 动力电池龙头
      search_keywords: 宁德时代, CATL
    - name: 比亚迪
      region: 中国
      business: 电池+整车
      search_keywords: 比亚迪
    - name: LG新能源
      region: 韩国
      business: 动力电池
      search_keywords: LG新能源, LG Energy Solution
```
