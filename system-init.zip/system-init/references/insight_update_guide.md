# Insight.md 更新指南

## 层级

- system
- workflows
- projects

## 更新信息流程

把关键信息更新到正确的层级与正确的文档中，并保持字段间一致性与可执行性。

## 内部结构（共 6 个区块）

### 1. 关键决策（Key decisions）
- 做了什么决策
- 决策理由和收益是什么
- 决策约束是什么

### 2. 关键试错（Key trials）
- 尝试的方向
- 观察到的结果/信号
- 结论/教训

### 3. 权衡与约束触发点（Tradeoffs & constraint triggers）
- 权衡对立
- 触发约束/条件
- 最终取舍

### 4. 拒绝方案（Rejected considered）
- 已被拒绝的方案
- 为什么不选

### 5. 备选方案（Alternatives considered）
- 已决策的问题中，未明确拒绝但尚未尝试/实施的方案

### 6. 不确定性与后续验证（Open questions）
- 尚未决策的问题
- 不确定点
- 计划验证手段
- 预期判据
