---
name: system-init
description: This skill defines the project system architecture, behavioral constraints, and document-management rules. It should be loaded at the start of every session in this workspace. It governs how context.md, insight.md, and state.md are structured and updated across system/workflow/project levels, and enforces quality and anti-retry rules.
---

# System Init

## Overview

This skill encodes the workspace-level operating rules for the `/Users/heloise/Desktop/agent` project. It defines the three-level system architecture (system → workflows → projects), three key document types (context.md, insight.md/process_insight.md, state.md), and all behavioral constraints for session startup, error handling, task completion, and document updates.

## System Architecture

### Three Levels

| Level | Directory | Purpose |
|-------|-----------|---------|
| system | `0_system/` | System-wide info: skills, system-level context.md, system-level insight.md |
| workflows | `1_workflows/` | Workflow-level info: workflow-level context.md, workflow-level insight.md |
| projects | `2_projects/` | Project-level info: project-level context.md, state.md, process_insight.md |

### Three Document Types

- **context.md** — Result information (focus on *how to use*)
- **insight.md / process_insight.md** — Process information (decision points, trial-and-error, summaries)
- **state.md** — Status record

## Session Startup Rules

At the start of every session:

1. Read system-level information from `0_system/`
2. When the user enters a project, read the relevant workflow info and project info. Project directories contain many files — focus on reading `context.md` and `insight.md` only.
3. Load all available skills

## Behavioral Constraints

### Error Handling

When encountering import/dependency errors:
- First determine: is this a code problem or an environment limitation?
- If uncertain, ask the user before deciding whether to write to context.md.

### Avoid Repeated Failures

Before planning or attempting something, check relevant `context.md` files for prior failure records. Do not retry paths known to fail.

### Task Completion Rules

When a phased task is completed:

- **state.md update** — Ask the user whether to update state.md. When writing state.md:
  - Keep it concise (no low-value details)
  - Record: date, completed steps, generated documents, current progress, next steps (if any)

- **context.md update** — Self-determine whether to update. Strict criteria (ALL must be met):
  - The current task is runnable/executable with no errors
  - No unfinished features remain

- **insight.md update** — Self-determine whether to update. Criteria (ANY ONE is sufficient):
  - Discussion occurred
  - A decision was made
  - Trial-and-error occurred
  - A practice was adopted
  - A trade-off due to constraints was made
  - An unresolved question needs tracking

### Task End Rules

When a task ends:

1. **Create/update skills:**
   - Ask whether to summarize as a skill. Output the expected skill info for confirmation: name, trigger, steps. Keep the skill name concise and clear.
   - If confirmed, generate the skill markdown file with: skill name, trigger conditions, execution steps.
   - Before creating: check if a similar trigger already exists. If highly similar, prefer reusing or updating the existing skill.
   - New skills must be maintained under `0_system/skills/`. Keep consistency when modifying.
   - Maintain a `skills.csv` file under `0_system/skills/` recording: skill name, purpose, trigger, execution count. Update this file on skill creation, update, or invocation.

2. **Create/update context.md**
3. **Create/update insight.md**
4. **Push to remote repository**

## Context.md Update Workflow

When updating context.md, follow the detailed procedure in `references/context_update_guide.md`. Key principles:

- Update the correct level (system / workflow / project) with the correct document.
- Maintain field consistency and executability.
- Use the three-part output format: A. Update Plan → B. Block-level Patches → C. Consistency Check.
- Wait for user confirmation before modifying files.
- Never ask the user to re-explain; all extraction must be based on task results and observed changes.
- If insufficient information for a block: mark it as "缺少信息" and ask minimal follow-up questions (≤3).
- Do not add large unrelated sections.

### Internal Structure of context.md

1. 项目类型 (which workflow)
2. 适用场景/触发条件 (When to use)
3. 目标与质量标准 (What good looks like)
4. 输入清单 (Input)
5. 约束条件 (Constraints)
6. 工作指令 (Workflow instructions)
7. 失败模式 (Failure modes)
8. 复用方式 (Reuse)
9. 证据/示例 (Examples)

### Level Boundaries

- **system layer**: Abstract rules / universal principles. Avoid toolchain-specific details.
- **workflow layer**: Abstract handling of failures/deviations caused by generic workflow patterns. Reusable judgment frameworks.
- **project layer**: Project-specific probe fields, tool failure fallbacks, deviation tracking, and concrete processes.

### Linked Update Rules

When changes are detected in task results, update related blocks simultaneously:
- New/modified Input → Also update Failure modes, What good looks like, Constraints, Judgment, Workflow instructions.
- Fixed output deviation / failure handling → Also update Failure modes, What good looks like, Judgment, Workflow instructions.
- New reusable strategy → Update Reuse.

## Insight.md Update Workflow

Update insight.md at the correct level with the following internal structure:

1. **关键决策 (Key decisions)** — Decision made + rationale & benefits + constraints
2. **关键试错 (Key trials)** — Direction attempted + observed results/signals + conclusion/lesson
3. **权衡与约束触发点 (Tradeoffs & constraint triggers)** — Trade-off pair + trigger condition + final choice
4. **拒绝方案 (Rejected considered)** — Rejected alternatives + why rejected
5. **备选方案 (Alternatives considered)** — Decided issues where alternatives are not yet rejected but not yet tried
6. **不确定性与后续验证 (Open questions)** — Undecided questions + uncertainty points + planned verification method + expected criteria

## Model Quality

| Model | Status | Notes |
|-------|--------|-------|
| `deepseek-v4-flash` | ✅ Available | Primary model, reliable quality, good value |
| `glm-5.1` | ✅ Available | Backup model, reliable quality, expensive |
| `hy3_preview` | ❌ Not recommended | Poor quality — do not use even if cheaper/faster. Wastes time for both sides. |

> The user has explicitly stated: do not pick poor models to save cost. Use recommended models; there is no time or interest for trial-and-error with bad models.

## Resources

### references/context_update_guide.md

Detailed field templates, linked update rules, consistency check items, and output format for context.md updates. Load this reference when performing a context.md update.

### references/insight_update_guide.md

Detailed field structure and entry templates for insight.md updates. Load this reference when performing an insight.md update.
