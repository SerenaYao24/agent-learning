#!/usr/bin/env python3
"""
巨潮资讯网(cninfo.com.cn) 业绩公告查询 + PDF内容提取脚本
"""

import urllib.request
import urllib.parse
import urllib.error
import json
import ssl
import sys
import os
import tempfile
import re
import time

ssl._create_default_https_context = ssl._create_unverified_context

SEARCH_URL = "https://www.cninfo.com.cn/new/fulltextSearch/fullTextSearch"
PDF_BASE_URL = "https://static.cninfo.com.cn/finalpage"

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
    "Accept": "application/json, text/javascript, */*; q=0.01",
    "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
    "X-Requested-With": "XMLHttpRequest",
    "Origin": "https://www.cninfo.com.cn",
    "Referer": "https://www.cninfo.com.cn/new/fulltextSearch",
}


def search_announcements(keyword, page_num=1, page_size=30):
    """搜索巨潮资讯网公告"""
    data = {
        "searchkey": keyword,
        "sdate": "",
        "edate": "",
        "isfulltext": "false",
        "sortName": "",
        "sortType": "",
        "pageNum": str(page_num),
        "pageSize": str(page_size),
    }
    post_data = urllib.parse.urlencode(data).encode("utf-8")
    req = urllib.request.Request(SEARCH_URL, data=post_data, headers=HEADERS, method="POST")
    with urllib.request.urlopen(req, timeout=30) as resp:
        result = json.loads(resp.read().decode("utf-8"))

    total = result.get("totalAnnouncement", 0) or result.get("total", 0) or 0
    announcements = result.get("announcements", []) or []
    return announcements, total


def download_and_extract_pdf(pdf_url):
    """下载PDF并提取文本"""
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix='.pdf')
    tmp_path = tmp.name
    tmp.close()
    try:
        req = urllib.request.Request(pdf_url, headers=HEADERS)
        with urllib.request.urlopen(req, timeout=30) as resp:
            with open(tmp_path, 'wb') as f:
                f.write(resp.read())
        if os.path.getsize(tmp_path) < 1000:
            os.unlink(tmp_path)
            return ""
        text = ""
        try:
            from pypdf import PdfReader
            reader = PdfReader(tmp_path)
            texts = [page.extract_text().strip() for page in reader.pages if page.extract_text()]
            text = '\n\n'.join(texts)
        except ImportError:
            try:
                import pdfplumber
                with pdfplumber.open(tmp_path) as pdf:
                    texts = [page.extract_text().strip() for page in pdf.pages if page.extract_text()]
                    text = '\n\n'.join(texts)
            except ImportError:
                pass
        os.unlink(tmp_path)
        return text.strip()
    except Exception as e:
        if os.path.exists(tmp_path):
            os.unlink(tmp_path)
        return ""


def get_pdf_url(announcement_id, announcement_time):
    date_part = announcement_time.split(" ")[0] if announcement_time else ""
    return f"{PDF_BASE_URL}/{date_part}/{announcement_id}.PDF"


def main():
    # 解析参数
    keyword = None
    exclude_codes = set()
    i = 1
    while i < len(sys.argv):
        if sys.argv[i] == "--exclude" and i + 1 < len(sys.argv):
            i += 1
            for code in sys.argv[i].split(","):
                code = code.strip()
                if code:
                    exclude_codes.add(code)
        else:
            keyword = sys.argv[i]
        i += 1

    if not keyword:
        print("用法: python3 fetch_cninfo_announcements.py <关键词> [--exclude 000001,000002,...]", file=sys.stderr)
        sys.exit(1)

    print(f"搜索关键词: {keyword}", file=sys.stderr)
    if exclude_codes:
        print(f"排除已有股票代码: {', '.join(sorted(exclude_codes))}", file=sys.stderr)
    announcements, total = search_announcements(keyword)

    if not announcements:
        print("未搜索到公告", file=sys.stderr)
        print(json.dumps([], ensure_ascii=False))
        sys.exit(0)

    print(f"共 {total} 条，当前页 {len(announcements)} 条", file=sys.stderr)
    
    # 先过滤掉已存在的，再下载PDF
    new_announcements = []
    for ann in announcements:
        stock_code = ann.get("secCode", "") or ann.get("stockCode", "")
        if stock_code in exclude_codes:
            stock_name = ann.get("secName", "") or ann.get("stockName", "")
            print(f"  跳过 {stock_name}({stock_code}) — 已存在", file=sys.stderr)
        else:
            new_announcements.append(ann)
    
    print(f"新公告: {len(new_announcements)} 条，已跳过: {len(announcements) - len(new_announcements)} 条", file=sys.stderr)

    results = []
    for ann in new_announcements:
        title = ann.get("announcementTitle", "") or ann.get("title", "")
        stock_code = ann.get("secCode", "") or ann.get("stockCode", "")
        stock_name = ann.get("secName", "") or ann.get("stockName", "")
        ann_id = ann.get("announcementId", "") or ann.get("id", "")
        org_id = ann.get("orgId", "") or ""
        ann_time = ann.get("announcementTime", "") or ann.get("publishTime", "")

        if ann_time and ann_time.isdigit():
            try:
                import datetime
                ann_time = datetime.datetime.fromtimestamp(int(ann_time)/1000).strftime("%Y-%m-%d")
            except:
                pass

        print(f"  处理: {stock_name}({stock_code})", file=sys.stderr)
        pdf_url = get_pdf_url(ann_id, ann_time)
        pdf_text = download_and_extract_pdf(pdf_url)
        print(f"    文本: {len(pdf_text)} 字符", file=sys.stderr)

        detail_url = f"https://www.cninfo.com.cn/new/disclosure/detail?orgId={org_id}&announcementId={ann_id}" if org_id else pdf_url

        results.append({
            "title": title,
            "stock_code": stock_code,
            "stock_name": stock_name,
            "announcement_id": ann_id,
            "announcement_time": ann_time,
            "pdf_url": pdf_url,
            "detail_url": detail_url,
            "pdf_text": pdf_text,
        })
        time.sleep(0.5)

    print(json.dumps(results, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
